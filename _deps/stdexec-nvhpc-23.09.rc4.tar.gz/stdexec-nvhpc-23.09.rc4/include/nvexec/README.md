### Supported

- [x] `then`
- [x] `bulk`
- [x] `transfer_when_all_with_variant`
- [x] `transfer_when_all`
- [x] `when_all_with_variant`
- [x] `when_all`
- [x] `split`
- [x] `transfer_just`
- [x] `upon_stopped`
- [x] `upon_error`
- [x] `let_value`
- [x] `let_error`
- [x] `let_stopped`
- [x] `schedule_from`
- [x] `transfer`
- [x] `sync_wait`
- [x] `ensure_started`
- [x] `start_detached`

### TO DO

- [x] Tests
- [x] NVHPC
- [ ] Executing unknown senders on GPU

